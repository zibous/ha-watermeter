#pragma once

// ToDo: refactor drivers

#include "driver_apator_16_2.h"
#include "driver_fhkvdataiii.h"
#include "driver_hydrocalm3.h"
#include "driver_apatoreitn.h"
#include "driver_apator_08.h"
#include "driver_unismart.h"
#include "driver_ultrimis.h"
#include "driver_mkradio3.h"
#include "driver_mkradio4.h"
#include "driver_vario451.h"
#include "driver_bmeters.h"
#include "driver_amiplus.h"
#include "driver_evo868.h"
#include "driver_qwater.h"
#include "driver_itron.h"
#include "driver_qheat.h"
#include "driver_izar.h"
#include "driver_elf.h"